# Compose Operator Helm Chart

This Helm chart installs the [Compose Operator](https://github.com/fomsio/compose-operator) into your Kubernetes (v1.27+) or Openshift cluster (v4.6+).

## TL;DR


```sh
# Add the repo to helm (typically use a tag rather than main):
helm repo add foms-charts https://fomsio.github.io/helm-charts

# Install the operator
helm install compose-operator --namespace foms-system --create-namespace \
  --set crd.enabled=true \
  foms-charts/compose-operator
```

## Introduction

The Compose operator is installed into the `foms-system` namespace for Kubernetes clusters.

The Compose and ComposeSet Custom Resource Definitions (CRDs) can either be installed manually (the recommended approach, part of the Helm chart (`crd.enabled=true`).
Installing the CRDs as part of the Helm chart is not recommended for production setups, since uninstalling the Helm chart will also uninstall the CRDs and subsequently delete any remaining CRs.
The CRDs allow you to configure individual parts of your Compose setup:

* [`MysqlReplication`](https://github.com/fomsio/compose-operator/blob/dev/doc/compose-operator-api.md#mysqlreplication)
* [`MysqlGroupReplication`](https://github.com/fomsio/compose-operator/blob/dev/doc/compose-operator-api.md#mysqlgroupreplication)
* [`ProxysqlSync`](https://github.com/fomsio/compose-operator/blob/dev/doc/compose-operator-api.md#proxysqlsync)
* [`PostgresReplication`](https://github.com/fomsio/compose-operator/blob/dev/doc/compose-operator-api.md#postgresreplication)
* [`RedisReplication`](https://github.com/fomsio/compose-operator/blob/dev/doc/compose-operator-api.md#redisreplication)
* [`RedisCluster`](https://github.com/fomsio/compose-operator/blob/dev/doc/compose-operator-api.md#rediscluster)

After the installation of the Compose-operator chart, you can start inject the Custom Resources (CRs) into your cluster.
The Compose operator will then automatically start installing the components.
Please see the documentation of each CR for details.

## Uninstalling

Before removing the Compose operator from your cluster, you should first make sure that there are no instances of resources managed by the operator left:

```sh
kubectl get MysqlReplication,MysqlGroupReplication,ProxysqlSync,PostgresReplication,RedisReplication,RedisCluster --all-namespaces
```

Now you can use Helm to uninstall the Compose operator:

```sh
# for Kubernetes:
helm uninstall --namespace foms-system compose-operator --wait

# optionally remove repository from helm:
helm repo remove foms-charts
```

**Important:** if you installed the CRDs with the Helm chart (by setting `crd.enabled=true`), the CRDs will be removed as well: this means any remaining Compose resources (e.g. Compose Pipelines) in the cluster will be deleted!

If you installed the CRDs manually, you can use the following command to remove them (*this will remove all Compose resources from your cluster*):
```
kubectl delete crd MysqlReplication,MysqlGroupReplication,ProxysqlSync,PostgresReplication,RedisReplication,RedisCluster --ignore-not-found
```
